package com.abs.adminapp

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCompositionContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.HorizontalAlignmentLine
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import com.abs.adminapp.ui.theme.AdminAppTheme
import com.abs.adminapp.utils.Const
import com.abs.adminapp.utils.LocationActivity
import com.abs.adminapp.utils.LocationModule
import org.intellij.lang.annotations.JdkConstants.HorizontalAlignment

class MainActivity : ComponentActivity() {

    companion object{
        lateinit var activity : ComponentActivity
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activity = this
        setContent {
            AdminAppTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    //Greeting("Android")
                    FeatureItems(
                        listItems = listOf(
                            Const.SHOW_POPUP,
                            Const.LOCK_SCREEN,
                            Const.LOCATION,
                            Const.CHANGE_ICON
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Composable
fun FeatureItems(listItems: List<String>) {
    val context= LocalContext.current
    Column(
        modifier = Modifier.fillMaxWidth().fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        listItems.forEach {textData->

            ClickableText(text = AnnotatedString("$textData"), style = TextStyle(fontSize = 30.sp), onClick = {
                when(textData){
                    Const.SHOW_POPUP->{

                    }
                    Const.LOCK_SCREEN->{

                    }
                    Const.LOCATION->{
                        context.startActivity(Intent(context,LocationActivity::class.java))
                        /*LocationModule(context as ComponentActivity).getLocation(){

                        }*/
                    }
                    Const.CHANGE_ICON->{

                    }
                }

            })
        }

    }
}

@Composable
fun PermissionPage(listItems: List<String>){
    val context= LocalContext.current
    Column(
        modifier = Modifier.fillMaxWidth().fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        listItems.forEach {textData->

            ClickableText(text = AnnotatedString("$textData"), style = TextStyle(fontSize = 30.sp), onClick = {
                when(textData){
                    Const.SHOW_POPUP->{

                    }
                    Const.LOCK_SCREEN->{

                    }
                    Const.LOCATION->{

                    }
                    Const.CHANGE_ICON->{

                    }
                }

            })
        }

    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    AdminAppTheme {
        Greeting("Android")
    }
}