package com.abs.adminapp.utils

enum class Options{
    SHOW_POPUP
}