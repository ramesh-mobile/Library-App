package com.abs.adminapp.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.location.LocationListenerCompat
import com.abs.adminapp.MainActivity


//get location attribute periodically
//get location attribute for one time only
//check gps status
//check network status
//geofencing


private const val TAG = "LocationModule"
class LocationModule(var activity: ComponentActivity) :  LocationListener{

    lateinit var locationManager : LocationManager
    private val gadgetQ = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    //private lateinit var activity : ComponentActivity
    private lateinit var onLocationFoundOperation:()->Unit

    fun getLocation(onLocationFoundOperation:()->Unit){
        //this.activity = activity
        this.onLocationFoundOperation = onLocationFoundOperation
        locationManager = activity.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        checkPermission()
    }

    private fun checkPermission(){
        var askPermission = arrayOf<String>()
        Const.INITIAL_PERMISSION.forEach {
            if(ActivityCompat.checkSelfPermission(activity, it)!= PackageManager.PERMISSION_GRANTED)
                askPermission+=(it)
        }

        if(askPermission.isNotEmpty())
            onPermissionContract.launch(askPermission)
        else{
            onLocationFoundOperation.invoke()
        }
    }

    private val onPermissionContract = activity.registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){
        Toast.makeText(activity, "on activity contracts", Toast.LENGTH_SHORT).show()
        if (gadgetQ) {
            if(ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED)
                locationPermissionContract.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }else{
            onLocationFoundOperation.invoke()
        }
    }

    private val locationPermissionContract = activity.registerForActivityResult(ActivityResultContracts.RequestPermission()){
        if(it){
            onLocationFoundOperation.invoke()
        }
    }









    override fun onLocationChanged(location: Location) {
        logPrint(TAG,"Location is :${location.getLocationString()}")
    }


}